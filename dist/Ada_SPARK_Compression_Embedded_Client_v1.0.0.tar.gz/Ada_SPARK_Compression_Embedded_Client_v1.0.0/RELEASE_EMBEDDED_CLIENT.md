# 📡 Ada SPARK Sıkıştırma - Embedded Client SDK (v1.0.0)
### STANAG-4586 & DO-178C Level-A Gömülü İstemci Kiti

Hedef Donanımlar:
- Raspberry Pi (CM4, Pi 4, Pi 5)
- Nvidia Jetson (Nano, Orin, Xavier)
- NXP i.MX, BeagleBone, Zynq ARM SBC
- STM32, ESP32, FreeRTOS (C99 Çekirdeği ile)

---

## 🚀 1-Komutla Kurulum (Raspberry Pi / Jetson):
```bash
sudo ./install.sh
```

## 🛰️ Uçak / Verici Modu (Ham Al -> Sıkıştır -> Yer İstasyonuna Fırlat):
```bash
python3 tactical_client.py --mode tx --ip 0.0.0.0 --port 5555 --dest-ip 192.168.1.100 --dest-port 5555 --algo algo-8
```

## ⚡ Saf C99 İle Mikrodenetleyici / Bare-Metal Kullanımı:
```bash
make
./tactical_embedded_core tx 5555 192.168.1.100 5555
```

---
© 2026 Muhammet Atmaca. MIT Lisansı.
