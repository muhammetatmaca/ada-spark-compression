# 🛡️ Ada SPARK Sıkıştırma Süiti - PC / Server Edition (v1.0.0)
### STANAG-4586 & DO-178C Level-A Yer İstasyonu & Aviyonik Veri Sunucusu

Bu paket, **Yer Kontrol İstasyonları (GCS), Komuta Kontrol Merkezleri ve PC İş İstasyonları** için hazırlanmış tam sürüm paketidir.

---

## 🚀 Başlatma Seçenekleri

### 1. Masaüstü Grafik Arayüzü (PRO Beyaz Kokpit GUI):
`start.bat` dosyasına çift tıklayın veya terminalden:
```bash
python app.py
```
- Çoklu UDP portlarını ve algoritmalarını görsel tabloda eşzamanlı izleyin.
- Klasör ve dosyaları deterministik olarak `.tact` arşivine dönüştürün.
- SPARK DO-178C Level-A matematiksel doğrulamalarını çalıştırın.

### 2. Arka Plan Aviyonik Sunucusu (Headless Server Daemon):
`start_server.bat` dosyasına çift tıklayın veya:
```bash
python tactical_server.py --ports 5555:algo-8:decompress 5556:algo-6:decompress --log server_telemetry.log
```
- Gömülü istemcilerden gelen sıkıştırılmış paketleri sıfır GUI yüküyle çözer, doğrular ve loglar.

---
© 2026 Muhammet Atmaca. MIT Lisansı.
